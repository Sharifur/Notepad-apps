<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>NoteBook App</title>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/dist/css/main.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/dist/css/bootstrap.css">
</head>

<body>
    <div class="container-fluid">
        <nav class="navbar  navbar-dark bg-primary">
            <button class="navbar-toggler hidden-sm-up" type="button" data-toggle="collapse" data-target="#navbar-header" aria-controls="navbar-header">
                &#9776;
            </button>
            <div class="collapse navbar-toggleable-xs" id="navbar-header">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">NoteBook App</a>
               
        </nav>
        <!-- /navbar -->
        <!-- Main component for call to action -->
        <?php echo $__env->yieldContent("container"); ?>
    </div>
    <!-- /container -->

    <script src="<?php echo e(url('/')); ?>/dist/js/jquery3.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/dist/js/bootstrap.js"></script>
</body>

</html>
