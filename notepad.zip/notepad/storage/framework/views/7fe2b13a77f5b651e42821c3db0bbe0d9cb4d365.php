<?php $__env->startSection('content'); ?>
<style> 
    .pl{
        padding-left: 20px;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading text-center"> 
                    <h3><?php echo e($allnotes->title); ?></h3>
                </div>
                <div class="panel-body text-center">
                    <div class="col-md-4 text-center">
                        <?php if(file_exists("images/notes/npic-{$allnotes->id}.{$allnotes->picture}")): ?>
                        <img class="img-responsive npic" src="<?php echo e(url('/')); ?>/images/notes/npic-<?php echo e($allnotes->id); ?>.<?php echo e($allnotes->picture); ?>" alt="">
                        <?php else: ?>
                        <img class="img-responsive npic" src="<?php echo e(url('/')); ?>/images/no-note.png" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="col-md-8 text-center">
                        <?php echo e($allnotes->description); ?>

                    </div>
                </div>
                <div class="panel-footer pull-right">
                    <a href="<?php echo e(url('/')); ?>/notes/edit/<?php echo e($allnotes->id); ?>" class="glyphicon glyphicon-edit pl">Ediit</a>
                    <a href="<?php echo e(url('/')); ?>/notes/delete/<?php echo e($allnotes->id); ?>" class="glyphicon glyphicon-trash pl">Delete</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>