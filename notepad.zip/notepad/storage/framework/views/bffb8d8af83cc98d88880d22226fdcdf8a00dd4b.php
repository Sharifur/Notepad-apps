<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header text-center">Edit Note</h1>
    </div>
</div>
<!-- /.row -->

<!-- Projects Row -->
<div class="row">
    <div class="col-md-8 col-md-offset-2 portfolio-item">
        
        

        <br>
        <br>
        <br>
        <?php $__currentLoopData = $match; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form class="form-horizontal" method="POST" enctype="multipart/form-data" action="<?php echo e(url('/notes/update')); ?>/<?php echo e($note->id); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>"/>
            <div class="form-group">
                <label for="title" >Title</label>
                <input type="text" class="form-control" name="title" value="<?php echo e($note->title); ?>" placeholder="Enter a Title Of your Note"/>
                <h6 class="text-danger"><?php echo e($errors->first('title')); ?></h6>
            </div>
            <div class="form-group">
                <label for="title" >Description</label>
                <textarea class="form-control" name="descr" rows="6"><?php echo e($note->description); ?></textarea>
                <h6 class="text-danger"><?php echo e($errors->first('descr')); ?></h6>
            </div>
            <br/>
            <div class="form-group">
                <label for="picture" >Select A Picture</label>
                <input type="file"  name="picture" >
                <br>
                <br/>
                <?php if(file_exists("images/notes/npic-{$note->id}.{$note->picture}")): ?>
                <a href="#">
                    <img width="50" height="50" src="<?php echo e(url('/')); ?>/images/notes/npic-<?php echo e($note->id); ?>.<?php echo e($note->picture); ?>" alt="">
                </a>
                <?php endif; ?>
                <h6 class="text-danger"><?php echo e($errors->first('picture')); ?></h6>
                <div class="space-4"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br/>
                <div class="clearfix form-actions">
                    <div class=" col-md-9">
                        <button class="btn btn-info" type="submit">
                            <i class="ace-icon fa fa-check bigger-110"></i>
                            Submit
                        </button>

                        &nbsp; &nbsp; &nbsp;
                        <button class="btn" type="reset">

                            Reset
                        </button>
                    </div>
                </div>
        </form> 
    </div>
</div>


<hr>

<script type="text/javascript" src="https://tinymce.cachefly.net/4.1/tinymce.min.js"></script>
<script type="text/javascript">

   tinymce.init({
      selector: "textarea",
      theme: "modern",
      setup: function(editor) {
         editor.on('change', function() {
            editor.save();
         });
      },
      plugins: [
         "advlist autolink lists link image charmap print preview hr anchor pagebreak",
         "searchreplace wordcount visualblocks visualchars code fullscreen",
         "insertdatetime media nonbreaking save table contextmenu directionality",
         "emoticons template paste textcolor colorpicker textpattern"
      ],
      toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
      toolbar2: "print preview media | forecolor backcolor emoticons",
      image_advtab: true,
      templates: [
         {title: 'Test template 1', content: 'Test 1'},
         {title: 'Test template 2', content: 'Test 2'}
      ],
      image_title: true,
      convert_urls: false,
      content_css: "css/content.css"
   });
</script>
<!-- Footer -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>