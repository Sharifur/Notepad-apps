<?php $__env->startSection('content'); ?>
<style>
    .pp-image{
        box-shadow: 0 0px 1px 6px #000;
        padding: 5px;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading text-center"> 
                    <h1> Edit Your Profile</h1>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4">
                            <?php if(file_exists("images/profile/pic-{$id}.{$alldata->picture}")): ?>
                            <img src="<?php echo e(url('/')); ?>/images/profile/pic-<?php echo e(Auth::user()->id); ?>.<?php echo e($alldata->picture); ?>" width="100" height="100" class="img-circle pp-image"/>
                            <?php else: ?>
                            <?php if($alluser->gender == "male"): ?>
                            <img src="<?php echo e(url('/')); ?>/images/male.png" width="200" class="img-circle pp-image" /> 
                            <?php else: ?>
                            <img src="<?php echo e(url('/')); ?>/images/female.png" width="200" class="img-circle pp-image"/> 
                            <?php endif; ?>
                            <?php endif; ?> 
                            <br/><br/>
                            <label>Change Profile picture</label>
                            <form method="POST" action="<?php echo e(url('/')); ?>/profile/picture/<?php echo e(Auth::user()->id); ?>" enctype="multipart/form-data" > 
                                <?php echo e(csrf_field()); ?>

                            <input type="file" name="pic"/>
                            <p><?php echo e(Session::get('picture')); ?></p>
                            <br/>
                            <input class="btn btn-primary" type="submit" value="Change" />
                            </form>
                            

                        </div>
                        <div class="col-md-8">
                            <form action="<?php echo e(url('/profile')); ?>/<?php echo e($alldata->id); ?>" method="POST"  > 
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>"/>
                                <div class="form-group">
                                    <label for="city">City</label>
                                    <input type="text" value="<?php echo e($alldata->city); ?>" class="form-control" name="city"/>  
                                </div>
                                <div class="form-group">
                                    <label for="country">Country</label>
                                    <input type="text" value="<?php echo e($alldata->country); ?>" class="form-control" name="country"/>  
                                </div>
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" value="<?php echo e($alldata->address); ?> " class="form-control" name="address"/>  
                                </div>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>