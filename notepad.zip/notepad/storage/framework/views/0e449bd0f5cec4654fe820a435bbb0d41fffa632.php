<?php $__env->startSection('container'); ?>

<div class="container ">
      <div class="row">
        <div class="col-xs-12">

            
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/')); ?>/country/update/">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label class="col-sm-2 control-label " for="form-field-1">Title </label>

                    <div class="col-sm-10">
                        <input type="text" id="form-field-1"  name="title" class="col-xs-10 col-sm-5 form-control" />

                    </div>
                    
                </div>
                <br/>
                <br/>
                <div class="form-group">
                    <label class="col-sm-2 control-label right " for="form-field-1">Description </label>

                    <div class="col-sm-10">
                        <textarea class="col-xs-10 col-sm-5 form-control" name="dersc" ></textarea>

                    </div>
                    
                </div>


                <br/>
                <br/>
                <div class="clearfix form-actions ">
                    <div class="col-md-offset-7 col-md-5">
                        <button class="btn btn-info" type="submit">
                            <i class="ace-icon fa fa-check bigger-110"></i>
                            Submit
                        </button>

                        &nbsp; &nbsp; &nbsp;
                        <button class="btn" type="reset">
                            <i class="ace-icon fa fa-undo bigger-110"></i>
                            Reset
                        </button>
                    </div>
                </div>
            </form>
            
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>