<!DOCTYPE html>
<html >
    <head>
        <meta charset="UTF-8">
        <title>Personal Notebook </title>
        <link rel="stylesheet" href="<?php echo e(url("/")); ?>/css/style.css">
    </head>
    <body>
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/profile-create')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
            <header>Create Your Profile</header>
            <div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                
                <label for="name" class="col-md-4 control-label">City</label>

                <div class="col-md-6">
                    <input id="name" type="text" class="form-control" name="city" value="<?php echo e(old('city')); ?>" required autofocus>

                    <?php if($errors->has('city')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('city')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group<?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
                <label for="country" class="col-md-4 control-label">Country</label>

                <div class="col-md-6">
                    <input id="email" type="text" class="form-control" name="country" value="<?php echo e(old('country')); ?>" required>

                    <?php if($errors->has('country')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('country')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                <label for="address" class="col-md-4 control-label">Address</label>

                <div class="col-md-6">
                    <input id="address" type="text" class="form-control" name="address" required>

                    <?php if($errors->has('address')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('address')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <label for="picture" class="col-md-4 control-label">Profile picture</label>

                <div class="col-md-6">
                    <input  type="file" name="picture"  >
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-6 col-md-offset-4">
                    <button type="submit" class="btn btn-primary">
                        Continue
                    </button>
                    
                </div>
            </div>
        </form>
    </body>
</html>
