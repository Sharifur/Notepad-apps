<?php $__env->startSection('content'); ?>

<style>
    .pp-image{
        box-shadow: 0 0px 1px 6px #000;
        padding: 5px;
    }

</style>

<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading text-center"> 
                    <h1> Welcome To Your Profile</h1>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4">

                            <?php if(file_exists("images/profile/pic-{$id}.{$alldata->picture}")): ?>
                            <img src="<?php echo e(url('/')); ?>/images/profile/pic-<?php echo e(Auth::user()->id); ?>.<?php echo e($alldata->picture); ?>" width="220" height="220" />
                            <?php else: ?>
                            <?php if($alluser->gender == "male"): ?>
                            <img src="<?php echo e(url('/')); ?>/images/male.png" width="200" class="img-circle pp-image" /> 
                            <?php else: ?>
                            <img src="<?php echo e(url('/')); ?>/images/female.png" width="200" class="img-circle pp-image"/> 
                            <?php endif; ?>
                            <?php endif; ?> 

                            <br/><br/>
                            

                        </div>
                        <div class="col-md-8">
                            <h4> Name : <?php echo e(Auth::user()->name); ?></h4>
                            <h4> Email : <?php echo e(Auth::user()->email); ?></h4>
                            <?php if($alluser->gender == "male"): ?>
                            <h4> Gender : Male </h4>
                            <?php else: ?>
                            <h4> Gender :  Female </h4>
                            <?php endif; ?>

                            <?php if($alldata->city == ""): ?>
                            <h4> City : No City Given</h4>
                            <?php else: ?>
                            <h4> City : <?php echo e($alldata->city); ?></h4>
                            <?php endif; ?>

                            <?php if($alldata->country == ""): ?>
                            <h4> Country : No Country Given</h4>
                            <?php else: ?>
                            <h4> Country : <?php echo e($alldata->country); ?></h4>
                            <?php endif; ?>

                            <?php if($alldata->address == ""): ?>
                            <h4> Address : No Address Given</h4>
                            <?php else: ?>
                            <h4> Address : <?php echo e($alldata->address); ?></h4>
                            <?php endif; ?>

                            <a href="<?php echo e(url('/profile')); ?>/<?php echo e(Auth::user()->id); ?>/edit" ><i class="fa fa-pencil-square-o ficon" aria-hidden="true"><span class="p-text">Edit Profile</span></i></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>